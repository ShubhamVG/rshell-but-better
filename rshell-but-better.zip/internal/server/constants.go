package server

import "time"

const (
	readTimeLimit = 2 * time.Second
)
